const navigation = document.getElementById("navigation");
console.log(navigation);
